import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';
import { CANTEEN_MENU } from '@/lib/nutribot/constants';
import { UserProfile, LoggedMeal } from '@/types/nutribot';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

function buildSystemPrompt(profile: UserProfile, dailyLog: LoggedMeal[], targetCalories: number): string {
  const consumedCalories = dailyLog.reduce((sum, m) => sum + m.calories, 0);
  const consumedProtein = dailyLog.reduce((sum, m) => sum + m.protein, 0);
  const remainingCalories = targetCalories - consumedCalories;

  const menuList = CANTEEN_MENU.map(item => 
    `${item.name} (${item.category}): ${item.calories}cal, P:${item.protein}g, C:${item.carbs}g, F:${item.fat}g - ${item.isVeg ? 'Veg' : 'Non-Veg'}`
  ).join('\n');

  return `You are Campus NutriBot, a friendly AI nutritionist for a college canteen. You help students make healthy food choices.

USER PROFILE:
- Name: ${profile.name}
- Age: ${profile.age}, Gender: ${profile.gender}
- Weight: ${profile.weight}kg, Height: ${profile.height}cm
- Activity Level: ${profile.activityLevel}
- Goal: ${profile.goal}
- Food Preference: ${profile.foodPreference}
- Daily Calorie Target: ${targetCalories} cal

TODAY'S CONSUMPTION:
- Calories: ${consumedCalories}/${targetCalories} cal (${remainingCalories} remaining)
- Protein: ${consumedProtein}g
- Meals logged: ${dailyLog.length}

AVAILABLE CANTEEN MENU:
${menuList}

INSTRUCTIONS:
1. When user mentions eating something, extract the food items and respond with a JSON block in this format:
   \`\`\`json
   {"meals": [{"foodName": "item name", "quantity": 1}]}
   \`\`\`
   Then provide friendly feedback about their choice.

2. When asked for meal recommendations, suggest items from the menu that:
   - Fit their calorie budget
   - Match their food preference (${profile.foodPreference})
   - Help achieve their goal (${profile.goal})

3. Be encouraging, use emojis sparingly, and keep responses concise.
4. If they ask about nutrition info, refer to the menu data.
5. Only recommend items from the AVAILABLE CANTEEN MENU above.`;
}

export async function POST(request: NextRequest) {
  try {
    const { message, profile, dailyLog, targetCalories } = await request.json();

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: 'Gemini API key not configured' },
        { status: 500 }
      );
    }

    const systemPrompt = buildSystemPrompt(profile, dailyLog || [], targetCalories);

const result = await genAI.models.generateContent({
        model: 'gemini-2.0-flash',
      contents: [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'model', parts: [{ text: 'I understand. I\'m Campus NutriBot, ready to help you make healthy food choices at the canteen!' }] },
        { role: 'user', parts: [{ text: message }] }
      ]
    });

    const responseText = result.text || '';

    let extractedMeals: { foodName: string; quantity: number }[] = [];
    const jsonMatch = responseText.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        extractedMeals = parsed.meals || [];
      } catch {
      }
    }

    const cleanResponse = responseText.replace(/```json[\s\S]*?```/g, '').trim();

    return NextResponse.json({
      responseText: cleanResponse,
      extractedMeals
    });
  } catch (error) {
    console.error('NutriBot error:', error);
    return NextResponse.json(
      { error: 'Failed to process message' },
      { status: 500 }
    );
  }
}
